 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pretraga destinacija</title>
    <link rel="stylesheet" href="wbp/public/css/styles.css">
 <section class="destination">   
        <h3>Najpopularnije destinacije</h3>
        <div class="destination-cards">
            <?php
            
            // Destinacije podaci
            $destinations = array(
                array(
                    'name' => 'Burj Khalifa',
                    'description' => 'Burj Khalifa je najviša zgrada na svetu i simbol futurističkog razvoja Dubaija. Sadrži poslovne prostore, luksuzne stanove, hotel Armani i spektakularne vidikovce na spratovima 124, 125 i 148. Dubai, UAE.',
                    'image' =>'public/images/BurjKalifa.jpg',
                    'rating' => 4.5
                ),
                array(
                    'name' => 'Ajfelova kula',
                    'description' => 'Simbol Pariza i jedan od najposećenijih spomenika na svetu. Pariz, Francuska',
                    'image' =>'public/images/AjfelovaKula.jpg',
                    'rating' => 4.2
                ),
                array(
                    'name' => 'Times Square',
                    'description' => 'Ikonični trg poznat po svetlećim reklamama, pozorištima i dočeku Nove godine. Njujork, SAD',
                    'image' =>'public/images/TimesSquare.jpg',
                    'rating' => 4.7
                ),
                array(
                    'name' => 'Niagara Falls',
                    'description' => 'Spektakularni vodopadi na granici SAD-a i Kanade, privlače milione turista.
SAD / Kanada.',
                    'image' =>'public/images/NiagaraFalls.jpg',
                    'rating' => 4.0
                ),
               
                
            );
   // Generisanje destinacija-kartice
   foreach ($destinations as $destination) {
    echo '<article class="card">';
    echo '<img class="card__background" src="' . $destination['image'] . '" alt="' . $destination['name'] . '">';
    echo '<div class="card__content | flow">';
    echo '<div class="card__content--container | flow">';
    echo '<h2 class="card__title">' . $destination['name'] . '</h2>';
    echo '<p class="card__description">' . $destination['description'] . '</p>';
    echo '</div>';
    echo '<div class="card__ratings">Rating: ' . $destination['rating'] . '</div>'; 
    echo '<a href="http://localhost/Destinacije" target="_self" class="card__button">Detalji</a>'; // Promenjen target u _self
    echo '</div>';
    echo '</article>';
}


?>
</div>
</section>
